<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="pro level 3" tilewidth="32" tileheight="32" tilecount="576" columns="32">
 <image source="tiles-png/pro level 3.jpeg" trans="ff00ff" width="1024" height="576"/>
</tileset>
